<?php
 return array (
  'captchastring' => 
  array (
    'script' => 'captchastring.php',
    'params' => 
    array (
      0 => 'captcha_name',
      1 => 'timets',
    ),
    'script_path' => 'modules/lhcaptcha/captchastring.php',
  ),
);
?>