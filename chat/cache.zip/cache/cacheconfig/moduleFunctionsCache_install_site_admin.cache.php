<?php
 return array (
  'install' => 
  array (
    'script' => 'install.php',
    'params' => 
    array (
      0 => 'step_id',
    ),
    'script_path' => 'modules/lhinstall/install.php',
  ),
);
?>