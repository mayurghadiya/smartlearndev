<?php
 return array (
  'default' => 
  array (
    'script' => 'default.php',
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'use',
    ),
    'script_path' => 'modules/lhfront/default.php',
  ),
);
?>