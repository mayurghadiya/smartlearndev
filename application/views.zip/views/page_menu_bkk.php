<div class="blog">
<div id="blog_text">
<?php echo $blog_text;?>
</div>
</div>
<div id="sidebar" class="sidebar">
    <!--Sidebar-->
    <div class="sidebar-page">
        <span class="sidebar-title">FormGet Tutorials</span>
        <div class="feature-menu">
		<ul>
	
		</ul>
            <!--<ul><li><a href="php">php</a></li>
                <li><a href="css">css</a></li>
                <li><a href="javascript">Javascript</a></li>
                <li><a href="codeigniter">CodeIgniter</a></li>
                <li><a href="html5">HTML5</a></li>
                <li><a href="mysql">mysql</a></li>
                <li><a href="mailget">mailget</a></li>
                <li><a href="others">Others</a></li>
            </ul>-->
        </div>
    </div>
    <!--/Sidebar-->
    <!--Sidebar-->
    <div class="sidebar-page">
        <span class="sidebar-title"> About Us</span>
        <div class="feature-menu">                                    
            <div class="textwidget"><p>Just get a FormGet account (It’s free), and you will be amazed with the ease you can create forms. It’s really easy and simple.  You don’t have to spend too much time it? </p></div>
        </div>
    </div>
    <!--/Sidebar-->
    <div class="sidebar-banner">
        <a href="#"><img src="<?php echo base_url(); ?>images/formget_add.jpg" alt=""> </a>
    </div>
</div>


