<?php
$edit_data = $this->db->select()
        ->from('cms_pages')
		->join('degree', 'degree.d_id = cms_pages.degree_id')
        ->join('course', 'course.course_id = cms_pages.am_course')
        ->join('semester', 'semester.s_id = cms_pages.am_semester')
        ->join('batch', 'batch.b_id = cms_pages.am_batch')
        ->where('am_id', $param2)
        ->get()
        ->row();

$batch = $this->db->get('batch')->result();
$degree = $this->db->get('degree')->result();
$course = $this->db->get_where('course', array(
            'degree_id' => $edit_data->d_id
        ))->result();
$query = "SELECT * FROM batch ";
$query .= "WHERE FIND_IN_SET($edit_data->d_id, degree_id) ";
$query .= "AND FIND_IN_SET($edit_data->am_course, course_id)";
$batch = $this->db->query($query)->result();
$semester = $this->db->get('semester')->result();
?>


<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    Edit CMS Page
                </div>
            </div>
            <div class="panel-body">
                <div class="tab-pane box" id="add" style="padding: 5px">
                    <div class="box-content">  
                        <form class="form-horizontal form-groups-bordered validate" id="cmspage" method="post" 
                              action="<?php echo base_url('index.php?admin/cms_manager/update/' . $edit_data->am_id); ?>" role="form">
							  <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Degree</label>
                                            <div class="col-sm-10 controls">
                                                <select id="edit_degree" name="degree" class="form-control">
                                                    <option value="">Select Degree</option>
                                                    <?php foreach ($degree as $d) { ?>
                                                        <option value="<?php echo $d->d_id; ?>"
                                                                <?php if ($d->d_id == $edit_data->d_id) echo 'selected'; ?>><?php echo $d->d_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                                <div id="test"></div>
                                            </div>
                                        </div>
                                    </div><!--./callout-->
                                </div><!--./col-->
                            </div><!--./row-->
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Course</label>
                                            <div class="col-sm-10 controls">
                                                <select id="edit_course" name="course" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php foreach ($course as $row) { ?>
                                                        <option value="<?php echo $row->course_id; ?>"
                                                                <?php if ($edit_data->am_course == $row->course_id) echo 'selected'; ?>><?php echo $row->c_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                                <div id="test"></div>
                                            </div>
                                        </div>
                                    </div><!--./callout-->
                                </div><!--./col-->
                            </div><!--./row-->
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Batch</label>
                                            <div class="col-sm-10 controls">
                                                <select name="batch" id="edit_batch" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php foreach ($batch as $row) { ?>
                                                        <option value="<?php echo $row->b_id; ?>"
                                                                <?php if ($edit_data->am_batch == $row->b_id) echo 'selected'; ?>><?php echo $row->b_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                            </div>	
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Semester</label>
                                            <div class="col-sm-10 controls">
                                                <select id="semester" name="semester" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php foreach ($semester as $row) { ?>
                                                        <option value="<?php echo $row->s_id; ?>"
                                                                <?php if ($edit_data->am_semester == $row->s_id) echo 'selected'; ?>><?php echo $row->s_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                                <div id="test"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Page Title</label>
                                            <div class="col-sm-10 controls">
                                                <input id="page_title" name="page_title" type="text" placeholder="Page Title" 
                                                       value="<?php echo $edit_data->am_title; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Page Slug</label>
                                            <div class="col-sm-10 controls">
                                                <input id="page_slug" name="page_slug" type="text" placeholder="Page Slug"
                                                       value="<?php echo $edit_data->am_url; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Content Type</label>
                                            <div class="col-sm-10 controls">
                                                <select class="form-control" id="content_type" name="content_type" id="content_type">
                                                    <option value="">Select</option>
                                                    <option value="0" <?php if ($edit_data->is_form == 0) echo 'selected'; ?>>Plain Content</option>
                                                    <option value="1" <?php if ($edit_data->is_form == 1) echo 'selected'; ?>>Form Content</option>
                                                </select>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="ck-editor">
                                <div class="col-sm-12 col-xs-12">	
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Page Content</label>
                                        <div class="col-sm-10 controls">												
                                            <div class="form-group">							
                                                <textarea id="edit_content_data" name="content_data" class="ckeditorcontent" rows="3" ><?php echo $edit_data->am_content; ?></textarea>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Panel Widget --> 
                                </div>
                                <!-- col-md-12 -->
                            </div>
                            <div class="form-group form-actions">
                                <div class="col-sm-2"> </div>
                                <div class="col-sm-10">
                                    <button type="submit" class="btn vd_btn vd_bg-green vd_white submit"><i class="icon-ok"></i> Save</button>
                                    <button type="button" class="btn vd_btn">Cancel</button>
                                </div>
                            </div>
                        </form>	
                    </div> 
                </div> 
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-2.2.1.min.js"></script>

<!-- Specific Page Scripts Put Here -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/adapters/jquery.js"></script>
<script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.validate.min.js"></script>

<!-- Specific Page Scripts END -->
<script type="text/javascript">
    $.validator.setDefaults({
        submitHandler: function (form) {
            form.submit();
        }
    });

    $().ready(function () {
        $("#edit_cms_page").validate({
            ignore: [],
            rules: {
                content_data: {
                    required: function () {
                        CKEDITOR.instances.content_data.updateElement();
                    }
                },
                course: "required",
                batch: "required",
                //year: "required",
                page_title: "required",
                semester: "required",
                page_slug: "required",
                content_type: "required",
                //content_data: "required"

            },
            messages: {
                course: "Please select course",
                batch: "Please select batch",
                //year: "Please select year",
                page_title: "Please enter page title",
                semester: "Please select semester",
                page_slug: "Please enter page slug",
                content_type: "Please enter content type",
                content_data: "Please enter content"
            }
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function ()
    {
        //CKEDITOR.replace( $('[data-rel^="ckeditor"]') );
        $('#edit_content_data').ckeditor();
        $('.submit').on('click', function () {
            for (instance in CKEDITOR.instances)
                CKEDITOR.instances[instance].updateElement();
            //$('#edit_cms_page').submit();
        });

    })
</script>

<script>
            $(document).ready(function () {
                //course by degree
                $('#edit_degree').on('change', function () {
                    var course_id = $('#edit_course').val();
                    var degree_id = $(this).val();

                    //remove all present element
                    $('#edit_course').find('option').remove().end();
                    $('#edit_course').append('<option value="">Select</option>');
                    var degree_id = $(this).val();
                    $.ajax({
                        url: '<?php echo base_url(); ?>index.php?admin/course_list_from_degree/' + degree_id,
                        type: 'get',
                        success: function (content) {
                            var course = jQuery.parseJSON(content);
                            $.each(course, function (key, value) {
                                $('#edit_course').append('<option value=' + value.course_id + '>' + value.c_name + '</option>');
                            })
                        }
                    })
                    batch_from_degree_and_course(degree_id, course_id);
                });

                //batch from course and degree
                $('#edit_course').on('change', function () {
                    var degree_id = $('#edit_degree').val();
                    var course_id = $(this).val();
                    batch_from_degree_and_course(degree_id, course_id);
                })

                //find batch from degree and course
                function batch_from_degree_and_course(degree_id, course_id) {
                    //remove all element from batch
                    $('#edit_batch').find('option').remove().end();
                    $.ajax({
                        url: '<?php echo base_url(); ?>index.php?admin/batch_list_from_degree_and_course/' + degree_id + '/' + course_id,
                        type: 'get',
                        success: function (content) {
                            $('#edit_batch').append('<option value="">Select</option>');
                            var batch = jQuery.parseJSON(content);
                            console.log(batch);
                            $.each(batch, function (key, value) {
                                $('#edit_batch').append('<option value=' + value.b_id + '>' + value.b_name + '</option>');
                            })
                        }
                    })
                }

            })
        </script>