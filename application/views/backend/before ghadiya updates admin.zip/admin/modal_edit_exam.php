<script>
</script>
<?php
$edit_data = $this->db->select('exam_manager.*, exam_type.*, course.*, semester.*')
        ->from('exam_manager')
        ->join('exam_type', 'exam_type.exam_type_id = exam_manager.em_type')
        ->join('course', 'course.course_id = exam_manager.course_id')
        ->join('semester', 'semester.s_id = exam_manager.em_semester')
        ->where('exam_manager.em_id', $param2)
        ->get()
        ->row();
            
$exam_type = $this->db->get('exam_type')->result();
$course = $this->db->get('course')->result();
$semester = $this->db->get('semester')->result();
$centerlist=$this->db->get('center_user')->result();
?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    <?php echo get_phrase('edit_exam'); ?>
                </div>
            </div>
            <div class="panel-body">
                <div class="box-content">
                    <?php echo form_open(base_url() . 'index.php?admin/exam/do_update/' . $edit_data->em_id, array('class' => 'form-horizontal form-groups-bordered validate', 'role' => 'form', 'id' => 'courseform', 'target' => '_top')); ?>
                    <div class="padded">
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Exam Name</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" name="exam_name" id="exam_name"
                                       value="<?php echo $edit_data->em_name; ?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Exam Type</label>
                            <div class="col-sm-7">
                                <select class="form-control" name="exam_type" id="exam_type">
                                    <option value="">Select</option>
                                    <?php foreach ($exam_type as $row) { ?>
                                    <option value="<?php echo $row->exam_type_id; ?>"
                                                <?php if ($edit_data->em_type == $row->exam_type_id) echo 'selected'; ?>><?php echo $row->exam_type_name; ?></option>
                                            <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Total Marks</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" name="total_marks" id="total_marks" value="<?php echo $edit_data->total_marks; ?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Year</label>
                            <div class="col-sm-7">
                                <select class="form-control" name="year" id="year">
                                    <option value="">Select</option>
                                    <?php for ($i = 2016; $i >= 2010; $i--) { ?>
                                    <option <?php echo $i; ?>
                                            <?php if ($edit_data->em_year == $i) echo 'selected'; ?>><?php echo $i; ?></option>
                                        <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Course</label>
                            <div class="col-sm-7">
                                <select class="form-control" name="course" id="course">
                                    <option value="">Select</option>
                                    <?php foreach ($course as $row) { ?>
                                    <option value="<?php echo $row->course_id; ?>"
                                                <?php if ($edit_data->course_id == $row->course_id) echo 'selected'; ?>><?php echo $row->c_name; ?></option>
                                            <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Semester</label>
                            <div class="col-sm-7">
                                <select class="form-control" name="semester" id="semester">
                                    <option value="">Select</option>
                                    <?php foreach ($semester as $row) { ?>
                                    <option value="<?php echo $row->s_id; ?>"
                                                <?php if ($edit_data->em_semester == $row->s_id) echo 'selected'; ?>><?php echo $row->s_name; ?></option>
                                            <?php } ?>
                                </select>
                            </div>
                        </div>
                           <div class="form-group">
                            <label class="col-sm-3 control-label">Center</label>
                            <div class="col-sm-5">
                                <?php
                                $centerexplode = explode(',', $edit_data->center_id);
                                print_r($centerexplode);
                                foreach ($centerlist as $row1) {
                                    if (in_array($row1->center_id, $centerexplode)) {
                                        echo in_array($row1->center_id, $centerexplode);
                                    }
                                }
                                ?>
                                <select class="form-control" name="center[]" id="center" multiple>
                                    <option value="">Select</option>
                                    <?php
                                    foreach ($centerlist as $row) {
                                        if (in_array($row->center_id, $centerexplode)) {
                                            ?>
                                    <option value="<?php echo $row->center_id; ?>" selected><?php echo $row->center_name; ?></option>
                                            <?php
                                        } else {
                                            ?>
                                    <option value="<?php echo $row->center_id; ?>"><?php echo $row->center_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Status</label>
                            <div class="col-sm-7">
                                <select class="form-control" name="status" id="status">
                                    <option value="">Select</option>
                                    <option value="1"
                                            <?php if ($edit_data->em_status == 1) echo 'selected'; ?>>Active</option>
                                    <option value="0"
                                            <?php if ($edit_data->em_status == 0) echo 'selected'; ?>>In-active</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Date</label>
                            <div class="col-sm-7">
                                <input type="text" id="datepicker-date123" name="date" class="form-control datepicker-normal"
                                       value="<?php echo $edit_data->em_date; ?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Start Date/Time</label>
                            <div class="col-sm-7">
                                <input type="datetime-local" name="start_date_time" id="start_date_time" class="form-control"
                                       value="<?php echo $edit_data->em_start_time; ?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">End Date/Time</label>
                            <div class="col-sm-7">
                                <input type="datetime-local" name="end_date_time" id="end_date_time" class="form-control"
                                       value="<?php echo $edit_data->em_end_time; ?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-7">
                                <button type="submit" class="btn btn-info">Update Exam</button>
                            </div>
                        </div>
                        </form>             
                    </div>
                </div>
            </div>
        </div>
            
        <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <script type="text/javascript">
            $(function () {
                
                $("#datepicker-date123").datepicker({
                    dateFormat: 'dd M yy',
                    changeMonth: true,
                    changeYear: true
                    
                });
            });
        </script>