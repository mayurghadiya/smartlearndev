<script>
</script>
<?php
$edit_data = $this->db->select()
        ->from('exam_time_table')
        ->join('exam_manager', 'exam_manager.em_id = exam_time_table.exam_id')
        ->join('subject_manager', 'subject_manager.sm_id = exam_time_table.subject_id')
        ->join('course', 'course.course_id = exam_manager.course_id')
        ->join('semester', 'semester.s_id = exam_manager.em_semester')
        ->where('exam_time_table.exam_time_table_id', $param2)
        ->get()
        ->row();

$exam_type = $this->db->get('exam_type')->result();
$course = $this->db->get('course')->result();
$semester = $this->db->get('semester')->result();
?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    <?php echo get_phrase('edit_exam_time_table'); ?>
                </div>
            </div>
            <div class="panel-body">
                <div class="box-content">
                    <?php echo form_open(base_url() . 'index.php?admin/exam_time_table/update/' . $edit_data->exam_time_table_id, array('class' => 'form-horizontal form-groups-bordered validate', 'role' => 'form', 'id' => 'courseform', 'target' => '_top')); ?>
                    <br/>
                    <div class="padded">
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Course Name</label>
                            <div class="col-sm-7">
                                <select name="course" id="edit_course" class="form-control" required="">
                                    <option value="">Select</option>
                                    <?php foreach ($course as $row) { ?>
                                        <option value="<?php echo $row->course_id; ?>"
                                                <?php if ($edit_data->course_id == $row->course_id) echo 'selected'; ?>><?php echo $row->c_name; ?></option>
                                            <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Semester</label>
                            <div class="col-sm-7">
                                <select class="form-control" id="edit_semester" name="semester" required="">
                                    <option value="">Select</option>
                                    <?php foreach ($semester as $row) { ?>
                                        <option value="<?php echo $row->s_id; ?>"
                                                <?php if ($edit_data->s_id == $row->s_id) echo 'selected'; ?>><?php echo $row->s_name; ?></option>
                                            <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Exam</label>
                            <div class="col-sm-7">
                                            <select class="form-control" id="edit_exam" name="exam" required="">
                                                <option value="">Select</option>
                                            </select>
                            </div>
                        </div> 
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Subject</label>
                            <div class="col-sm-7">
                                            <select class="form-control" id="edit_subject" name="subject" required="">
                                                <option value="">Select</option>
                                            </select>
                            </div>
                        </div> 
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Date</label>
                            <div class="col-sm-7">
                                <input type="text" id="exam_date" class="form-control datepicker-normal-edit" name="exam_date"
                                       value="<?php echo $edit_data->exam_date; ?>" required=""/>
                            </div>	
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Start Time</label>
                            <div class="col-sm-7">
                                <input type="time" id="start_time" class="form-control" name="start_time"
                                       value="<?php echo $edit_data->exam_start_time; ?>" required=""/>
                            </div>	
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">End Time</label>
                            <div class="col-sm-7">
                                <input type="time" id="end_time" class="form-control" name="end_time"
                                       value="<?php echo $edit_data->exam_end_time ?>" required=""/>
                            </div>	
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-7">
                                <button type="submit" class="btn btn-info">Update Time Table</button>
                            </div>
                        </div>
                        </form>   
                    </div>
                </div>
            </div>
        </div>

        <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <script type="text/javascript">
    $(function () {

        $(".datepicker-normal-edit").datepicker({
            dateFormat: 'dd M yy',
            changeMonth: true,
            changeYear: true

        });
    });
        </script>

        <script>
            var time_table_exam_id = '<?php echo $edit_data->exam_id; ?>';
            var subject_id = '<?php echo $edit_data->subject_id; ?>';

            function get_exam_list(course_id, semester_id) {
                $.ajax({
                    url: '<?php echo base_url(); ?>index.php?admin/get_exam_list/' + course_id + '/' + semester_id + '/' + time_table_exam_id,
                    type: 'get',
                    success: function (content) {
                        $('#edit_exam').html(content);
                    }
                });
            }

            function subject_list(course_id, semester_id) {
                $.ajax({
                    url: '<?php echo base_url(); ?>index.php?admin/subject_list/' + course_id + '/' + semester_id + '/' + subject_id,
                    type: 'get',
                    success: function (content) {
                        $('#edit_subject').html(content);
                    }
                })
            }

            $(document).ready(function () {
                var course_id = $('#edit_course').val();
                var semester_id = $('#edit_semester').val();
                get_exam_list(course_id, semester_id, time_table_exam_id);
                subject_list(course_id, semester_id, subject_id);

                $('#edit_course').on('click', function () {
                    var course_id = $(this).val();
                    var semester_id = $('#edit_semester').val();
                    get_exam_list(course_id, semester_id, time_table_exam_id);
                    subject_list(course_id, semester_id, subject_id);
                })

                $('#edit_semester').on('click', function () {
                    var course_id = $('#edit_course').val();
                    var semester_id = $(this).val();
                    get_exam_list(course_id, semester_id, time_table_exam_id);
                    subject_list(course_id, semester_id, subject_id);
                })
            })
        </script>