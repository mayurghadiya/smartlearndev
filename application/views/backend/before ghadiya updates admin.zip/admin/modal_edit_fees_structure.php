<?php
$edit_data = $this->db->get_where('fees_structure', array('fees_structure_id' => $param2))->row();
$course = $this->db->get('course')->result();
$semester = $this->db->get('semester')->result();
?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    Edit Fees Structure
                </div>
            </div>
            <div class="panel-body">
                <div class="tab-pane box" id="add" style="padding: 5px">
                    <div class="box-content">  
                        <form class="form-horizontal form-groups-bordered validate" id="edit_feesstructure" action="<?php echo base_url('index.php?admin/fees_structure/update/' . $edit_data->fees_structure_id); ?>" method="post" role="form">
                            <br/>
                            <div class="padded">
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Title</label>
                                    <div class="col-sm-7">
                                        <input type="text" id="title" name="title" class="form-control"
                                               value="<?php echo $edit_data->title; ?>"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Course Name</label>
                                    <div class="col-sm-7">
                                        <select class="form-control" id="course" name="course">
                                            <option value="">Select</option>
                                            <?php foreach ($course as $row) { ?>
                                                <option value="<?php echo $row->course_id; ?>"
                                                        <?php if ($edit_data->course_id == $row->course_id) echo 'selected'; ?>><?php echo $row->c_name; ?></option>
                                                    <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Semester Name</label>
                                    <div class="col-sm-7">
                                        <select class="form-control" id="semester" name="semester">
                                            <option value="">Select</option>
                                            <?php foreach ($semester as $row) { ?>
                                                <option value="<?php echo $row->s_id; ?>"
                                                        <?php if ($edit_data->sem_id == $row->s_id) echo 'selected'; ?>><?php echo $row->s_name; ?></option>
                                                    <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Fees</label>
                                    <div class="col-sm-7">
                                        <div class="box closable-chat-box">
                                            <input type="text" id="fees" class="form-control" name="fees" value="<?php echo $edit_data->total_fee; ?>"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-offset-3 col-sm-7">
                                        <button type="submit" class="btn btn-info">Edit Fees Structure</button>
                                    </div>
                                </div>
                        </form> 
                    </div> 
                </div> 
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.js"></script>
<script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.validate.min.js"></script>
<script type="text/javascript">
	$.validator.setDefaults({
		submitHandler: function (form) {
			var form = document.getElementsByTagName("form");
			form.submit();
		}
	});

	$().ready(function () {
		$("#edit_feesstructure").validate({
			rules: {
				course: "required",
				semester: "required",
				fees:  {
					required: true,
					currency: ['$', false]
            },
				title: "required"
			},
			messages: {
				course: "Please select Course Name",
				semester: "Please select semester name",
				fees: {
					required: "Please Enter  Fees",
					currency: "Please Enter Valid Amount"
				},
				title: "Please enter title"
			}
		});
	});
</script>