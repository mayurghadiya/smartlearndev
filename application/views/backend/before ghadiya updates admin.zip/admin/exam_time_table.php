<!-- Middle Content Start -->    
<div class="vd_content-wrapper">
    <div class="vd_container">
        <div class="vd_content clearfix">
            <div class="vd_head-section clearfix">
                <div class="vd_panel-header">
                    <ul class="breadcrumb">
                        <li><a href="index.html">Home</a> </li>
                        <li><a href="pages-custom-product.html">Pages</a> </li>
                        <li class="active">Time Table</li>
                    </ul>
                    <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
                        <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
                        <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
                        <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
                    </div>
                </div>
            </div>
            <div class="vd_title-section clearfix">
                <div class="vd_panel-header no-subtitle">
                    <h1>Time Table</h1>
                </div>
            </div>
            <div class="vd_content-section clearfix">
                <div class="row">
                    <div class="col-sm-12">								
                        <!------CONTROL TABS START------>
                        <ul class="nav nav-tabs bordered">
                            <li class="active">
                                <a href="#list" data-toggle="tab"><i class="entypo-menu"></i> 
                                    Time Table List
                                </a></li>
                            <li>
                                <a href="#add" data-toggle="tab"><i class="entypo-plus-circled"></i>
                                    Add Exam Time Table
                                </a></li>
                        </ul>
                        <!------CONTROL TABS END------>

                        <div class="tab-content">
                            <!----TABLE LISTING STARTS-->
                            <div class="tab-pane box active" id="list">

                                <div class="panel-body table-responsive">
                                    <table class="table table-striped" id="data-tables">
                                        <thead>
                                            <tr>
                                                <th><div>#</div></th>
                                                <th width="15%">Course</th>
                                                <th>Semester</th>
                                                <th>Exam</th>
                                                <th>Subject</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $counter = 1;
                                            foreach ($time_table as $row) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $counter; ?></td>
                                                    <td><?php echo $row->c_name; ?></td>
                                                    <td><?php echo $row->s_name; ?></td>
                                                    <td><?php echo $row->em_name; ?></td>
                                                    <td><?php echo $row->subject_name; ?></td>
                                                    <td><?php echo $row->exam_date; ?></td>
                                                    <td><?php echo $row->exam_start_time . ' to ' . $row->exam_end_time; ?></td>
                                                    <td class="menu-action">
                                                        <a href="#" onclick="showAjaxModal('<?php echo base_url(); ?>index.php?modal/popup/modal_edit_exam_time_table/<?php echo $row->exam_time_table_id; ?>');" data-original-title="edit" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-yellow vd_yellow"><i class="fa fa-pencil"></i></a>

                                                        <a href="#" onclick="confirm_modal('<?php echo base_url(); ?>index.php?admin/exam_time_table/delete/<?php echo $row->exam_time_table_id; ?>');" data-original-title="delete" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-red vd_red"><i class="fa fa-times"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php
                                                $counter++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!----TABLE LISTING ENDS--->


                            <!----CREATION FORM STARTS---->
                            <div class="tab-pane box" id="add" style="padding: 5px">
                                <div class="box-content">                	
                                    <?php echo form_open(base_url() . 'index.php?admin/exam_time_table/create', array('class' => 'form-horizontal form-groups-bordered validate', 'role' => 'form', 'id' => 'courseform', 'target' => '_top')); ?>
                                    <br/>
                                    <div class="padded">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Course Name</label>
                                            <div class="col-sm-5">
                                                <select name="course" id="course" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php foreach ($course as $row) { ?>
                                                        <option value="<?php echo $row->course_id; ?>"><?php echo $row->c_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Semester</label>
                                            <div class="col-sm-5">
                                                <select class="form-control" id="semester" name="semester">
                                                    <option value="">Select</option>
                                                    <?php foreach ($semester as $row) { ?>
                                                        <option value="<?php echo $row->s_id; ?>"><?php echo $row->s_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Exam</label>
                                            <div class="col-sm-5">
                                                <select class="form-control" id="exam" name="exam">
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Subject</label>
                                            <div class="col-sm-5">
                                                <select class="form-control" id="subject" name="subject">
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Date</label>
                                            <div class="col-sm-5">
                                                <input type="text" id="exam_date" class="form-control datepicker-normal" name="exam_date"/>
                                            </div>	
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Start Time</label>
                                            <div class="col-sm-5">
                                                <input type="text" id="start_time" class="form-control timepicker" name="start_time"/>
                                            </div>	
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">End Time</label>
                                            <div class="col-sm-5">
                                                <input type="text" id="end_time" class="form-control timepicker" name="end_time"/>
                                            </div>	
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-3 col-sm-5">
                                                <button type="submit" class="btn btn-info">Add Time Table</button>
                                            </div>
                                        </div>
                                        </form>               
                                    </div>                
                                </div>
                                <!----CREATION FORM ENDS-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>              
        </div>
        <!-- row --> 
    </div>
    <script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.js"></script>
    <script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.validate.min.js"></script>

    <script type="text/javascript">
                                                            $.validator.setDefaults({
                                                                submitHandler: function (form) {
                                                                    form.submit();
                                                                }
                                                            });

                                                            $().ready(function () {
                                                                $("#courseform").validate({
                                                                    rules: {
                                                                        course: "required",
                                                                        semester: "required",
                                                                        exam: "required",
                                                                        subject: "required",
                                                                        exam_date: "required",
                                                                        start_time: "required",
                                                                        end_time: "required"
                                                                    },
                                                                    messages: {
                                                                        course: "Please select Course Name",
                                                                        semester: "Please select semester",
                                                                        exam: "Please select exam",
                                                                        subject: "Please select subject",
                                                                        exam_date: "Please enter date",
                                                                        start_time: "Please enter start time",
                                                                        end_time: "Please enter end time"
                                                                    }
                                                                });
                                                            });
    </script>

    <script>
        function get_exam_list(course_id, semester_id) {
            $.ajax({
                url: '<?php echo base_url(); ?>index.php?admin/get_exam_list/' + course_id + '/' + semester_id,
                type: 'get',
                success: function (content) {
                    $('#exam').html(content);
                }
            });
        }

        function subject_list(course_id, semester_id) {
            $.ajax({
                url: '<?php echo base_url(); ?>index.php?admin/subject_list/' + course_id + '/' + semester_id,
                type: 'get',
                success: function (content) {
                    $('#subject').html(content);
                }
            })
        }

        $(document).ready(function () {
            $('#course').on('click', function () {
                var course_id = $(this).val();
                var semester_id = $('#semester').val();
                get_exam_list(course_id, semester_id);
                subject_list(course_id, semester_id);
            })

            $('#semester').on('click', function () {
                var course_id = $('#course').val();
                var semester_id = $(this).val();
                get_exam_list(course_id, semester_id);
                subject_list(course_id, semester_id);
            })
        })
    </script>

    <script type="text/javascript">
        $(window).load(function ()
        {
            "use strict";
            $(".datepicker-normal").datepicker({
                dateFormat: 'dd M yy',
                changeMonth: true,
                changeYear: true

            });
        });

    </script>
<link rel="stylesheet" type="text/css" href="assets/css/jquery.timepicker.css">
<script type="text/javascript" src="assets/js/jquery.timepicker.js"></script>