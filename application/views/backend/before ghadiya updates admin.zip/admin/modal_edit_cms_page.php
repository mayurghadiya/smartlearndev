<?php
$edit_data = $this->db->select()
        ->from('cms_pages')
        ->join('course', 'course.course_id = cms_pages.am_course')
        ->join('semester', 'semester.s_id = cms_pages.am_semester')
        ->join('batch', 'batch.b_id = cms_pages.am_batch')
        ->where('am_id', $param2)
        ->get()
        ->row();

$batch = $this->db->get('batch')->result();
$course = $this->db->get('course')->result();
$semester = $this->db->get('semester')->result();
?>


<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    Edit CMS Page
                </div>
            </div>
            <div class="panel-body">
                <div class="tab-pane box" id="add" style="padding: 5px">
                    <div class="box-content">  
                        <form class="form-horizontal form-groups-bordered validate" id="cmspage" method="post" 
                              action="<?php echo base_url('index.php?admin/cms_manager/update/' . $edit_data->am_id); ?>" role="form">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Course</label>
                                            <div class="col-sm-10 controls">
                                                <select id="user_type" id="course" name="course" class="form-control">
                                                    <option value="">--- Select Course ---</option>
                                                    <?php foreach ($course as $row) { ?>
                                                        <option value="<?php echo $row->course_id; ?>"
                                                                <?php if ($edit_data->am_course == $row->course_id) echo 'selected'; ?>><?php echo $row->c_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                                <div id="test"></div>
                                            </div>
                                        </div>
                                    </div><!--./callout-->
                                </div><!--./col-->
                            </div><!--./row-->
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Select Batch</label>
                                            <div class="col-sm-10 controls">
                                                <select name="batch" id="batch" class="form-control">
                                                    <option value="">--- Select Batch ---</option>
                                                    <?php foreach ($batch as $row) { ?>
                                                        <option value="<?php echo $row->b_id; ?>"
                                                                <?php if ($edit_data->am_batch == $row->b_id) echo 'selected'; ?>><?php echo $row->b_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                            </div>	
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Select Semester</label>
                                            <div class="col-sm-10 controls">
                                                <select id="semester" name="semester" class="form-control">
                                                    <option value="">--- Select Semester ---</option>
                                                    <?php foreach ($semester as $row) { ?>
                                                        <option value="<?php echo $row->s_id; ?>"
                                                                <?php if ($edit_data->am_semester == $row->s_id) echo 'selected'; ?>><?php echo $row->s_name; ?></option>
                                                            <?php } ?>
                                                </select>
                                                <div id="test"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Page Title</label>
                                            <div class="col-sm-10 controls">
                                                <input id="page_title" name="page_title" type="text" placeholder="Page Title" 
                                                       value="<?php echo $edit_data->am_title; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Page Slug</label>
                                            <div class="col-sm-10 controls">
                                                <input id="page_slug" name="page_slug" type="text" placeholder="Page Slug"
                                                       value="<?php echo $edit_data->am_url; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="callout callout-info">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Content Type</label>
                                            <div class="col-sm-10 controls">
                                                <select class="form-control" id="content_type" name="content_type" id="content_type">
                                                    <option value="">Select</option>
                                                    <option value="0" <?php if ($edit_data->is_form == 0) echo 'selected'; ?>>Plain Content</option>
                                                    <option value="1" <?php if ($edit_data->is_form == 1) echo 'selected'; ?>>Form Content</option>
                                                </select>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="ck-editor">
                                <div class="col-sm-12 col-xs-12">	
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Page Content</label>
                                        <div class="col-sm-10 controls">												
                                            <div class="form-group">							
                                                <textarea id="edit_content_data" name="content_data" class="ckeditorcontent" rows="3" ><?php echo $edit_data->am_content; ?></textarea>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Panel Widget --> 
                                </div>
                                <!-- col-md-12 -->
                            </div>
                            <div class="form-group form-actions">
                                <div class="col-sm-2"> </div>
                                <div class="col-sm-10">
                                    <button type="button" class="btn vd_btn vd_bg-green vd_white submit"><i class="icon-ok"></i> Save</button>
                                    <button type="button" class="btn vd_btn">Cancel</button>
                                </div>
                            </div>
                        </form>	
                    </div> 
                </div> 
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-2.2.1.min.js"></script>

<!-- Specific Page Scripts Put Here -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/adapters/jquery.js"></script>

<!-- Specific Page Scripts END -->
<script type="text/javascript">
    $(document).ready(function ()
    {
        //CKEDITOR.replace( $('[data-rel^="ckeditor"]') );
        $('#edit_content_data').ckeditor();
        $('.submit').on('click', function () {
            for (instance in CKEDITOR.instances)
                CKEDITOR.instances[instance].updateElement();
            $('#cmspage').submit();
        });
        
    })
</script>