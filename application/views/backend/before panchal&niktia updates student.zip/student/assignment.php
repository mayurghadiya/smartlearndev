<!-- Middle Content Start -->
<style>
	#upload{
    display:none
	}
</style>   
<!--<script src="<?=base_url()?>assets/js/ckeditor.js"></script>-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/adapters/jquery.js"></script>
<script type="text/javascript">
	$(window).load(function ()
	{
		//CKEDITOR.replace( $('[data-rel^="ckeditor"]') );
		$('.ckeditor').ckeditor();
	})
</script>
<div class="content">
	<div class="container">
		<div class="vd_content-wrapper">
			<div class="">
				<div class="vd_content clearfix">
					<div class="vd_title-section clearfix">
						<div class="vd_panel-header">
							<h1><?php echo $page_title?></h1>            
						</div>
					</div>
					<div class="vd_content-section clearfix">
						<?php
							if($param=='online')
							{
							?>
							<div class="row">
								<div class="col-sm-12">
									<div class="panel widget light-widget">
										
										<?php echo form_open(base_url() . 'index.php?student/assignment/create_online_assignment' , array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top' ,'role'=>'form','id'=>'frmonlineassignment', 'enctype' => 'multipart/form-data'));?>
										<div  class="panel-body">
											<div class="row">
												<div class="col-sm-9">                        
													<div class="form-group">
														<label class="col-sm-3 control-label">Assignment Title</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<input type="text" class="form-control" name="title" id="title" />
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">Course</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<select name="course" id="course">
																		<option value="">Select course</option>
																		<?php
																			$course=$this->db->get_where('course',array('course_status'=>1))->result();
																			foreach($course as $crs)
																			{
																			?>
																			<option value="<?=$crs->course_id?>"><?=$crs->c_name?></option>
																			<?php
																			}
																		?>
																	</select>
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">Batch</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<select name="batch" id="batch">
																		<option value="">Select batch</option>
																		<?php
																			$databatch=$this->db->get_where('batch',array('b_status'=>1))->result();
																			foreach($databatch as $row)
																			{
																			?>
																			<option value="<?=$row->b_id?>"><?=$row->b_name?></option>
																			<?php
																			}
																		?>
																	</select>
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">Semester</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<select name="semester" id="semester">
																		<option value="">Select semester</option>
																		<?php
																			$datasem=$this->db->get_where('semester',array('s_status'=>1))->result();
																			foreach($datasem as $rowsem)
																			{
																			?>
																			<option value="<?=$rowsem->s_id?>"><?=$rowsem->s_name?></option>
																			<?php
																			}
																		?>
																	</select>
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">Assignment URL</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<input type="text" class="form-control" name="assignmenturl" id="assignmenturl" />
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">Submission Date</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<input type="text" class="form-control" name="submissiondate" id="submissiondate" />
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">Description</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<textarea class="form-control" name="description" id="description"></textarea>
																</div>
															</div>
														</div>
													</div>
													<div class="form-group">
														<label class="col-sm-3 control-label">File Upload</label>
														<div class="col-sm-9 controls">
															<div class="row mgbt-xs-0">
																<div class="col-xs-9">
																	<input type="file" class="form-control" name="assignmentfile" id="assignmentfile" />
																</div>
															</div>
														</div>
													</div>
													<div class="pd-20">
														<button class="btn vd_btn vd_bg-green col-md-offset-3"> Add Assignment</button>
													</div>
												</div>
											</div>
										</div>
									</form>
									
								</div>
							</div>
							
						</div>
						
						<?php
						}
						elseif($param=='completed_assignment')
						{
						?>
						
						<div class="row">
							<div class="col-sm-12">
								<div class="panel-body table-responsive">
									<div class="panel">
										
										<table class="table table-striped" id="data-tables">
											<thead>
												<tr>
													<th><div>#</div></th>
													<th><div>Title</div></th>												
													<th><div>Course</div></th>												
													<th><div>Batch</div></th>												
													<th><div>Sem</div></th>												
													<th><div>Assignment Url</div></th>												
													<th><div>Date of submission</div></th>	
													<th><div>Status</div></th>	
													<th><div>Description</div></th>	
												</tr>
											</thead>
											<tbody>
												<?php $count = 1;foreach($assignment as $row): ?>
												<tr>
													<td><?php echo $count++;?></td>
													<td><?php echo $row->assign_title;?></td>	
													<td>
														<?php 
															foreach($course as $crs)
															{
																if($crs->course_id==$row->course_id)
																{
																	echo $crs->c_name;
																}
															}
														?>
													</td>
													<td>
														<?php 
															foreach($batch as $bch)
															{
																if($bch->b_id==$row->assign_batch)
																{
																	echo $bch->b_name;
																}
															}
														?>
													</td>
													<td>
														<?php 
															foreach($semester as $sem)
															{
																if($sem->s_id==$row->assign_sem)
																{
																	echo $sem->s_name;
																}
															}														
														?>													
													</td>	
													<td><?php echo $row->assign_url;?></td>	
													<td><?php echo  date("F d, Y",strtotime($row->assign_dos));?></td>		
													<td><?php echo  $row->assign_online_status;?></td>		
													<td><?php echo  html_entity_decode($row->assign_desc);?></td>		
												</tr>
												<?php endforeach;?>						
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<?php
						}
						elseif($param="offline")
						{
						?>
						
						<div class="row">
							<div class="col-sm-12">
								<div class="panel widget light-widget">
									
									<?php echo form_open(base_url() . 'index.php?student/assignment/create_offline_assignment' , array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top' ,'role'=>'form','id'=>'frmonlineassignment', 'enctype' => 'multipart/form-data'));?>
									<div  class="panel-body">
										<div class="row">
											<div class="col-sm-9">                        
												<div class="form-group">
													<label class="col-sm-3 control-label">Assignment Title</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<input type="text" class="form-control" name="title" id="title" />
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">Course</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<select name="course" id="course">
																	<option value="">Select course</option>
																	<?php
																		$course=$this->db->get_where('course',array('course_status'=>1))->result();
																		foreach($course as $crs)
																		{
																		?>
																		<option value="<?=$crs->course_id?>"><?=$crs->c_name?></option>
																		<?php
																		}
																	?>
																</select>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">Batch</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<select name="batch" id="batch">
																	<option value="">Select batch</option>
																	<?php
																		$databatch=$this->db->get_where('batch',array('b_status'=>1))->result();
																		foreach($databatch as $row)
																		{
																		?>
																		<option value="<?=$row->b_id?>"><?=$row->b_name?></option>
																		<?php
																		}
																	?>
																</select>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">Semester</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<select name="semester" id="semester">
																	<option value="">Select semester</option>
																	<?php
																		$datasem=$this->db->get_where('semester',array('s_status'=>1))->result();
																		foreach($datasem as $rowsem)
																		{
																		?>
																		<option value="<?=$rowsem->s_id?>"><?=$rowsem->s_name?></option>
																		<?php
																		}
																	?>
																</select>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">Assignment URL</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<input type="text" class="form-control" name="assignmenturl" id="assignmenturl" />
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">Submission Date</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<input type="text" class="form-control" name="submissiondate" id="submissiondate" />
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">Description</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<textarea id="content_data" name="content_data" class="ckeditor" data-rel="ckeditor" rows="3" ></textarea>
															</div>
														</div>
													</div>
												</div>
												
												<div class="form-group">
													<label class="col-sm-3 control-label">File Upload</label>
													<div class="col-sm-9 controls">
														<div class="row mgbt-xs-0">
															<div class="col-xs-9">
																<input type="file" class="form-control" name="assignmentfile" id="assignmentfile" />
															</div>
														</div>
													</div>
												</div>
												<div class="pd-20">
													<button class="btn vd_btn vd_bg-green col-md-offset-3"> Add Assignment</button>
												</div>
											</div>
										</div>
									</div>
								</form>
								
							</div>
						</div>
						
					</div>
					
					<?php
					}
				?>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<script type="text/javascript" src="<?=$this->config->item('js_path')?>jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="<?=$this->config->item('js_path')?>jquery.validate.min.js"></script>
<script type="text/javascript">
	$.validator.setDefaults({
		submitHandler: function(form) {			
			 form.submit();
		}
	});

	$().ready(function() {	
		$("#frmonlineassignment").validate({		
			rules: {
				title: "required",
				assignmenturl: {required:true,url: true},
				course: "required",
				batch: "required",
				semester: "required",
				description: "required",
				content_data: "required",
				sem_id: {
					  required: true
				},
				submissiondate:"required",
				assignmentfile:{required:true}
			},
			messages: {
				title: "Title is required",
				assignmenturl: "Valid assignment URL is required",
				course: "Course name is required",
				batch: "Batch is required",
				semester: "Semester is required",
				content_data: "Course description is required",
				description: "Description is required",
				submissiondate:"submission date is required",
				assignmentfile:"File is required",
			}
		});
	});
	


	$(window).load(function() 
{ "use strict"; 
 $( "#submissiondate" ).datepicker({ 
  dateFormat: 'dd M yy',
  changeMonth: true,
  changeYear: true
 
 });
});
</script>