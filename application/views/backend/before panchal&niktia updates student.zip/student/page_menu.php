<div class="vd_content-wrapper">
	<div class="vd_head-section clearfix"></div>
	<!--<hr/>-->
		<div class="vd_title-section clearfix">
			<div class="vd_panel-header">
			  <h1><?php echo $page_title; ?></h1>
			 </div>
		</div>
		 <div class="vd_banner vd_bg-white clearfix pd-20">
			<div class="container">
				<div class="vd_content clearfix">
					<div class="row">           
						<div class="panel-body"> 							
								<?php echo @$blog_text;?>
						</div>
					</div>
				</div>
			</div>
		</div>
</div>



