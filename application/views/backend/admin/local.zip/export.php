<!-- Middle Content Start -->    
<div class="vd_content-wrapper">
    <div class="vd_container">
        <div class="vd_content clearfix">
            <div class="vd_head-section clearfix">
                <div class="vd_panel-header">
                    <ul class="breadcrumb">
                        <li><a href="index.html">Home</a> </li>
                        <li><a href="pages-custom-product.html">Pages</a> </li>
                        <li class="active">Export</li>
                    </ul>
                    <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
                        <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
                        <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
                        <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
                    </div>
                </div>
            </div>
            <div class="vd_title-section clearfix">
                <div class="vd_panel-header no-subtitle">
                    <h1>Export</h1>
                </div>
            </div>
            <div class="vd_content-section clearfix">
                <div class="row">
                    <div class="col-sm-12">								
                        <!------CONTROL TABS START------>
                        <ul class="nav nav-tabs bordered">
                            <li class="active">
                                <a href="#list" data-toggle="tab"><i class="entypo-menu"></i> 
                                    Export Data
                                </a></li>

                        </ul>
                        <!------CONTROL TABS END------>

                        <div class="tab-content">
                            <!----TABLE LISTING STARTS-->
                            <div class="tab-pane box active" id="list">
                                <div class="box-content">   
                                    <br/>                  
                                    <form id="exportform" class="form-horizontal validate" action="#" method="post">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Select Module</label>
                                            <div class="col-sm-5">
                                                <select id="export_module" class="form-control" name="module_name" required="">
                                                    <option value="">Select</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/exam_manager'); ?>">Exam Manager</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/event_manager'); ?>">Event Manager</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/course'); ?>">Course</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/degree'); ?>">Degree</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/semester'); ?>">Semester</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/student'); ?>">Student</option>
                                                    <option value="exam_marks">Exam Marks</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/system_setting'); ?>">System Settings</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/project_manager'); ?>">Project Manager</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/admission_type'); ?>">Admission Type</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/batch'); ?>">Batch</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/fees_structure'); ?>">Fees Structure</option>
                                                    <option value="<?php echo base_url('index.php?admin/export_csv/subject'); ?>">Subject</option>
                                                </select>
                                            </div>
                                        </div> 
                                        <div id="main_course" style="display: none;" class="form-group">
                                            <label class="col-sm-3 control-label">Course Name</label>
                                            <div class="col-sm-5">
                                                <select id="course" name="course" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php foreach ($course as $row) { ?>
                                                        <option value="<?php echo $row->course_id; ?>"><?php echo $row->c_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="main_semester" style="display: none;" class="form-group">
                                            <label class="col-sm-3 control-label">Semester</label>
                                            <div class="col-sm-5">
                                                <select id="semester" name="semester" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php foreach ($semester as $row) { ?>
                                                        <option value="<?php echo $row->s_id; ?>"><?php echo $row->s_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="main_exam" style="display: none;" class="form-group">
                                            <label class="col-sm-3 control-label">Exam</label>
                                            <div class="col-sm-5">
                                                <select id="exam" name="exam" class="form-control">

                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-3 col-sm-5">
                                                <button id="export" type="submit" class="btn btn-info">Export</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>  
                            </div>
                            <!----TABLE LISTING ENDS--->

                        </div>
                    </div>
                </div>
            </div>
        </div>              
    </div>
    <!-- row --> 
</div>

<script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.js"></script>
<script type="text/javascript" src="<?= $this->config->item('js_path') ?>jquery.validate.min.js"></script>

<script>
    var custom_link = '';
    $.validator.setDefaults({
        submitHandler: function (form) {
            form.submit;
        }
    });
    $().ready(function () {
        $("#exportform").validate({
            rules: {
                export_module: "required"
            },
            messages: {
                export_module: "Please enter export module",
            }
        });
    });
    $('#export_module').on('change', function () {
        var module_name = $(this).val();
        if (module_name == 'exam_marks') {
            required_details();
            show_exam_details();
        } else {
            remove_required_details();
            hide_exam_details();
        }
    });

    $('#export').on('click', function () {
        //alert(1);return false;
        var module_name = $('#export_module').val();
        if (module_name != '') {
            if (module_name == 'exam_marks') {
                //show_exam_details();
                var exam_value = $('#exam').val();
                location.href = '<?php echo base_url(); ?>index.php?admin/export_csv/exam_marks/'+exam_value;
            } else {
                location.href = module_name;
            }
        }

    })
    $('form').on('submit', function () {
        return false;
    });

    function hide_exam_details() {
        $('#main_course').css('display', 'none');
        $('#main_semester').css('display', 'none');
        $('#main_exam').css('display', 'none');
    }
    function show_exam_details() {
        $('#main_course').css('display', 'block');
        $('#main_semester').css('display', 'block');
        $('#main_exam').css('display', 'block');
    }
    function required_details() {
        $('#course').attr('required', 'required');
        $('#semester').attr('required', 'required');
        $('#exam').attr('required', 'required');
    }

    function remove_required_details() {
        $('#course').removeAttr('required');
        $('#semester').removeAttr('required');
        $('#exam').removeAttr('required');
    }
</script>

<script>
    function get_exam_list(course_id, semester_id, exam_id) {
        $.ajax({
            url: '<?php echo base_url(); ?>index.php?admin/get_exam_list/' + course_id + '/' + semester_id,
            type: 'get',
            success: function (content) {
                $('#exam').html(content);
            }
        });
    }

    $(document).ready(function () {
        var course_id = $('#course').val();
        var semester_id = $('#semester').val();
        get_exam_list(course_id, semester_id);

        $('#course').on('change', function () {
            var course_id = $(this).val();
            var semester_id = $('#semester').val();
            get_exam_list(course_id, semester_id);
            //subject_list(course_id, semester_id);
        })

        $('#semester').on('change', function () {
            var course_id = $('#course').val();
            var semester_id = $(this).val();
            var exam_id = $('#exam').val();
            get_exam_list(course_id, semester_id, exam_id);
            //subject_list(course_id, semester_id);
        })
    })
</script>