<div class="vd_navbar vd_nav-width vd_navbar-tabs-menu vd_navbar-left  ">

    <div class="navbar-menu clearfix">
        <div class="vd_panel-menu hidden-xs">
            <span data-original-title="Expand All" data-toggle="tooltip" data-placement="bottom" data-action="expand-all" class="menu" data-intro="<strong>Expand Button</strong><br/>To expand all menu on left navigation menu." data-step=4 >
                <i class="fa fa-sort-amount-asc"></i>
            </span>                   
        </div>
        <h3 class="menu-title hide-nav-medium hide-nav-small"></h3>
        <div class="vd_menu">
            <ul>                   
                <li>
                    <a href="<?php echo base_url('index.php?video_streaming'); ?>">
                        <span class="menu-icon"><i class="fa fa-desktop"></i></span> 
                        <span class="menu-text">Video Streaming</span>  
                    </a>
                </li> 
            </ul>
            <!-- Head menu search form ends -->         
        </div>             
    </div>
    <div class="navbar-spacing clearfix">
    </div>
    <div class="vd_menu vd_navbar-bottom-widget">
        <ul>
            <li>
                <a href="<?php echo base_url(); ?>index.php?login/logout">
                    <span class="menu-icon"><i class="fa fa-sign-out"></i></span>          
                    <span class="menu-text">Logout</span>             
                </a>

            </li>
        </ul>
    </div>     
</div>    
<!-- Middle Content Start -->